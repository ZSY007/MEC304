function retval = obj_exercise(X1,X2)
  retval = 0.1*X1 + 0.05773*X2; % Objective function
 end