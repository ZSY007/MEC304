function retval = inecond1(X1,X2)
  retval = 0.6./X1 + 0.3464./X2; % Constraint equality function
 end